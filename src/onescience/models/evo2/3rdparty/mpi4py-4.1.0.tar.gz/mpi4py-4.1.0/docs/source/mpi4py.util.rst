mpi4py.util
===========

.. module:: mpi4py.util
   :synopsis: Miscellaneous utilities.

.. versionadded:: 3.1.0

The :mod:`mpi4py.util` package collects miscellaneous utilities
within the intersection of Python and MPI.

.. toctree::
   :maxdepth: 1

   mpi4py.util.dtlib
   mpi4py.util.pkl5
   mpi4py.util.pool
   mpi4py.util.sync


.. Local variables:
.. fill-column: 79
.. End:
