Citation
========

If MPI for Python been significant to a project that leads to an
academic publication, please acknowledge that fact by citing the
project.

.. include:: ../../CITATION.rst
