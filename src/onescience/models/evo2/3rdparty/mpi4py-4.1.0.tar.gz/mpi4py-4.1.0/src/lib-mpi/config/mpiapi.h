#ifndef PyMPI_CONFIG_MPIAPI_H
#define PyMPI_CONFIG_MPIAPI_H

#include "mpi-11.h"
#include "mpi-12.h"
#include "mpi-20.h"
#include "mpi-22.h"
#include "mpi-30.h"
#include "mpi-31.h"
#include "mpi-40.h"
#include "mpi-41.h"
#include "mpi-50.h"
#include "mpi-51.h"
#include "mpi-60.h"

#endif /* !PyMPI_CONFIG_MPIAPI_H */
