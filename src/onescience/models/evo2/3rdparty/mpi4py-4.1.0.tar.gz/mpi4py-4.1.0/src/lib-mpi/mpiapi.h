PyMPI_EXTERN_C_BEGIN
#include "largecnt.h"
#include "mpiapi40.h"
#include "mpiapi41.h"
#include "mpiapi50.h"
PyMPI_EXTERN_C_END
#include "mpixf16.h"
#include "mpiulfm.h"
