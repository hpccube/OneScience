#if defined(MPI_VERSION)
#if (MPI_VERSION > 5) || (MPI_VERSION == 5 && MPI_SUBVERSION >= 1)

/* #define PyMPI_HAVE_MPI_TYPECLASS_LOGICAL 1 */

#endif
#endif
